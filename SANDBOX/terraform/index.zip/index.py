def my_handler(event, context):
  print(event)
  return 'all-good'
